import React from "react";

function Courses() {
  return (
    <div>
      <h2>Enrolled Courses</h2>
      <ul>
        <li>DevOps</li>
        <li>Full Stack Development</li>
        <li>Cloud Computing</li>
      </ul>
    </div>
  );
}

export default Courses;
