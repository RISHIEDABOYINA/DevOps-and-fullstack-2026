import React from "react";

function Dashboard() {
  return (
    <div>
      <h2>Student Dashboard</h2>
      <p>Overview of student performance</p>
    </div>
  );
}

export default Dashboard;
