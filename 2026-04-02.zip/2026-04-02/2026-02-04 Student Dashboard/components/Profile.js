import React from "react";

function Profile() {
  return (
    <div>
      <h2>Student Profile</h2>
      <p>Name: Student Name</p>
      <p>Roll No: 12345</p>
      <p>Department: CSE (AI)</p>
    </div>
  );
}

export default Profile;
