import React from "react";
import { NavLink } from "react-router-dom";

function NavBar() {
  return (
    <nav>
      <NavLink to="/">Dashboard</NavLink> |{" "}
      <NavLink to="/courses">Courses</NavLink> |{" "}
      <NavLink to="/profile">Profile</NavLink>
    </nav>
  );
}

export default NavBar;
